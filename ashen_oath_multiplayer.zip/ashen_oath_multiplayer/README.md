# ASHEN OATH — Online Knight vs Boss

A playable two-device PvP Soulslike arena. One player controls the **Ashen Knight**; the other controls the **Hollow King** boss. Rooms use a six-character invite code. Combat, cooldowns, healing, stamina, invincibility and hit validation run on the Node server, not in the player's browser.

## Quick start

Requires Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000 on your computer. A second player can join using another browser on the same network via your LAN IP, but **for remote play you must deploy the server to a public host**.

## Deploy to a public URL (Render)

1. Upload this repository to GitHub.
2. Go to https://dashboard.render.com/ and choose **New > Web Service**. Connect your GitHub repository.
3. Select the Node runtime, `npm install` as build command and `npm start` as start command (or use the included `render.yaml` blueprint).
4. Once deployment finishes, copy your `https://...onrender.com` link. It supports secure `wss://` WebSocket connections automatically.
5. Open the public link on **two different devices**. On the first, choose *Knight* and **Create Room**. Click **Copy Invite Link** and send it to your opponent. On the second device, choose *Boss* and use the invite link and click **Join**.

Free plans may sleep during inactivity and take a little time to wake. Rooms are kept in server memory; a host restart wipes active rooms. For production, add durable session storage or a multi-instance room adapter.

## The rules

- Exactly two players per room: one **Knight**, one **Boss**. A match starts when both have joined.
- Move using **WASD**, aim with **mouse**, click for light attacks, press **Q** for heavy attacks, and **Space** to dodge/lunge. Actions consume stamina.
- **Knight**: 120 HP, three flasks (press **R**, healing 44 HP), faster movement and quick sword strikes.
- **Hollow King**: 350 HP, slower movement and powerful cleaves; hold **E** to guard, reducing incoming damage but draining stamina. No healing.
- Attacks wind up before hitting; red cones warn about incoming strikes. Roll through danger during invincibility frames. Attacks only hit enemies in the indicated cone and range.
- First player to bring the opponent's HP to zero wins. Both players can request a rematch.
- On touchscreens, use the virtual joystick and action buttons. Aiming automatically targets the opponent.

## Architecture

- `server.js` — Node HTTP server, `ws` WebSocket room management, authoritative simulation at 30 ticks/sec, 30-Hz state updates.
- `public/index.html` — responsive standalone canvas game, online lobby, touch and desktop inputs, status UI.
- `render.yaml` — deployment blueprint.

## Important limits

This prototype is **2D top-down**, not a 3D Dark Souls clone. It supports two remote players through a deployed server. It does **not** include matchmaking, persistence, accounts, encryption beyond host-provided HTTPS/WSS, or network interpolation. It is not a publicly deployed game until you follow the hosting instructions.
